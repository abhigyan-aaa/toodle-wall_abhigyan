import React, { useState } from "react";
import { Button } from "react-bootstrap";
import { Modal, ModalBody, ModalHeader } from "reactstrap";
import Post_temp from "../components/Post_temp";

const Board = () => {
  const [modal, setModal] = useState(false);
  return (
    <>
      <Modal size="lg" isOpen={modal} toggle={() => setModal(!modal)}>
        <ModalHeader toggle={() => setModal(!modal)}>
          Create a Post
          <p className="desc">write something for your post</p>
        </ModalHeader>
        <ModalBody>
          <div class="form-group">
            <fieldset disabled="">
              <label class="form-label" for="disabledInput">
                Subject
              </label>
              <input
                class="form-control"
                id="disabledInput"
                type="text"
                placeholder="Subject..."
                disabled=""
              />
            </fieldset>
          </div>
          <div class="form-group my-2">
            {/* <label for="formFile" class="form-label mt-4">Default file input example</label> */}
            <input class="form-control" type="file" id="formFile" />
          </div>
          <div class="form-group">
            <fieldset disabled="">
              <label class="form-label" for="disabledInput">
                Whats on Your mind ?
              </label>
              <input
                class="form-control"
                id="disabledInput"
                type="text"
                placeholder="Type Here..."
                disabled=""
              />
            </fieldset>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-primary">
              Publish
            </button>
          </div>
        </ModalBody>
      </Modal>

      <header>
        <div className="my_board_nav">
          <div className="my_board_back">
            <i class="fa-solid fa-arrow-left"></i>
          </div>
          <div className="my_board_logo">
            <img src="logo2.jpg" alt="logo" className="logo" />
          </div>
          <div className="my_board_title">
            <p>My Boards name</p>
          </div>
          <div className="my_board_icon">
            <i class="fa-solid fa-magnifying-glass"></i>
            <b>|</b>
            <i class="fa-regular fa-bookmark"></i>
          </div>
        </div>
      </header>
      <div className="my_board_screen">
        <div className="my_board_screen_title">
          <h1>Your Posts</h1>
          <button
            type="button"
            class="btn btn-danger"
            onClick={() => setModal(true)}
          >
            <b> +Create Post</b>
          </button>
        </div>
        <div className="my_board_screen_content">
          <div className="my_board_screen_img">
            <img
              src="NoPostMobile.jpg"
              alt="logo"
              style={{ width: "300px", height: "300px" }}
            />
          </div>
          <h2 className="text-center">Nothing is here yet</h2>
          <p className="text-center">
            create your first post by clicking the "<b>+Create Post</b>" button
          </p>
        </div>
      </div>
        <Post_temp/>
    </>
  );
};

export default Board;
