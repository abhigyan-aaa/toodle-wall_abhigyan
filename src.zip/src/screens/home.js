import React from "react";
import Header from "../components/Header";
import Footer from "../components/Footer";
import Board_temp from "../components/Board_temp";


const Home = () => {
  return (
    <>
      <Header />
      <h1>My Boards</h1>

      <div className="boards">
        <Board_temp />
        <Board_temp />
        <Board_temp />
      </div>
      {/* <Footer /> */}
    </>
  );
};

export default Home;
