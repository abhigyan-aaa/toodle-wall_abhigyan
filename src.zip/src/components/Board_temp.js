import React from 'react'

const Board_temp = () => {
  return (
    <>
        <div className="board">
          <div className="board_left"></div>
          <div className="board_right">Title of board</div>
          <div className="board_option">
            <i class="fa-solid fa-ellipsis-vertical"></i>

          </div>
        </div>
    </>
  );
}

export default Board_temp;
