import React, {useState} from "react";
import { Button } from "react-bootstrap";
import { Modal, ModalBody, ModalHeader } from "reactstrap";

function Header() {
const [modal, setModal] = useState(false);

  return (
    <>
      <Modal size="lg" isOpen={modal} toggle={() => setModal(!modal)}>
        <ModalHeader toggle={() => setModal(!modal)}>
          Add Name For Your Board
        </ModalHeader>
        <ModalBody>
          <div class="form-group">
            <fieldset disabled="">
              <input
                class="form-control"
                id="disabledInput"
                type="text"
                placeholder="title..."
                disabled=""
              />
            </fieldset>
          </div>

          <div class="card my-3">
            <h4 className="mx-2"> Select Your Colour </h4>
            <p className="mx-2">
              Here are some templets to help you get stearted
            </p>

            <ul>
              <li class="color-item" id="red"></li>
              <li class="color-item" id="green"></li>
              <li class="color-item" id="amber"></li>
              <li class="color-item" id="blue"></li>
              <li class="color-item" id="gray"></li>
            </ul>
          </div>

          <div class="modal-footer">
            <button type="button" class="btn btn-danger">
              Create Board
            </button>
          </div>
        </ModalBody>
      </Modal>

      <header>
        <nav class="navbar navbar-expand-lg bg-light" data-bs-theme="light">
          <div class="container-fluid">
            <a class="navbar-brand" href="#">
              <img src="logo.jpg" alt="logo" className="logo" />
            </a>
            <button
              class="navbar-toggler"
              type="button"
              data-bs-toggle="collapse"
              data-bs-target="#navbarColor03"
              aria-controls="navbarColor03"
              aria-expanded="false"
              aria-label="Toggle navigation"
            >
              <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarColor03">
              <ul class="navbar-nav me-auto"></ul>
              <form class="d-flex">
                <input
                  class="form-control me-sm-2"
                  type="search"
                  placeholder="Search"
                />
              </form>
              <button type="button" class="btn btn-danger" onClick={()=>setModal(true)}>
                <b>+Create new board</b>
              </button>
            </div>
          </div>
        </nav>
      </header>
    </>
  );
}

export default Header;
